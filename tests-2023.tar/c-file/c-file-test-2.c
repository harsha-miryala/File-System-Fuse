#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <fcntl.h>
#include <string.h>
#include <errno.h>
#include <sys/time.h>
#include <sys/stat.h>
#include <pthread.h>

#include "ostypes.h"

#define NAMESIZE (1024)

int Verbose;
char Path[1024];
int Iterations;
int Agents;
int FileSize;
int FileCount;
int Depth;
int FanOut;

double Operations;
pthread_mutex_t OpsLock;

#define ONEMB (1024*1024)

struct agent_arg
{
	int max_size;
	int max_offset;
	int max_files;
	int iterations;
	char *path;
	uint depth;
	uint fanout;
};

typedef struct agent_arg AGENTARG;

void *agent(void *arg)
{
	AGENTARG *a = (AGENTARG *)arg;
	int fd;
	int i;
	int j;
	int f;
	int d;
	int offset;
	char *buf;
	int size;
	char *file_name;
	char dir_name[NAMESIZE];
	char idir[NAMESIZE];
	char ifile[NAMESIZE];
	char **fnames;
	int id;
	double local_ops = 0;
	int err;
	char *rbuf;
	char *wbuf;
	int bytes;
	uint fcount;
	uint depth;
	uint did;
	uint fid;

	memset(dir_name,0,sizeof(dir_name));

	rbuf = malloc(a->max_size+1);
	if(rbuf == NULL) {
		return(NULL);
	}
	wbuf = malloc(a->max_size+1);
	if(wbuf == NULL) {
		free(rbuf);
		return(NULL);
	}

	id = (int)(drand48() * 10000.0);

	sprintf(dir_name,"%s/dir%4.4d",
		a->path,
		id);

	err = mkdir(dir_name,0755);
	if(err < 0) {
		if(errno != EEXIST) {
			fprintf(stderr,"agent %d couldn't make dir %s\n",
				id,
				dir_name);
			goto out;
		}
	}

	fcount = drand48() * a->max_files;
	if(fcount == 0) {
		fcount = 1;
	}

	fnames = (char **)malloc(fcount * sizeof(char *));
	if(fnames == NULL) {
		fprintf(stderr,"agent %d no space for fnames\n",
			id);
		exit(1);
	}
	memset(fnames,0,sizeof(char*)*fcount);

	for(f=0; f < fcount; f++) {
		file_name = malloc(NAMESIZE);
		if(file_name == NULL) {
			fprintf(stderr,"agent %d no space for file name\n",
				id);
			exit(1);
		}
		memset(file_name,0,NAMESIZE);
		strncpy(file_name,dir_name,NAMESIZE);
		depth = drand48() * a->depth;
		if(depth == 0) {
			depth = 1;
		}
		for(d=0; d < depth; d++) {
			memset(idir,0,NAMESIZE);;
			did = drand48() * a->fanout;
			sprintf(idir,"dir%4.4d",did);
			strcat(file_name,"/");
			strcat(file_name,idir);
			err = mkdir(file_name,0755);
			if(err < 0) {
				if(errno != EEXIST) {
					fprintf(stderr,
					"agent %d couldn't create %s\n",
						file_name);
					goto out;
				}
			}
		}
		fid = drand48() * 10000;
		memset(ifile,0,sizeof(ifile));
		sprintf(ifile,"file%4.4d",fid);
		strcat(file_name,"/");
		strcat(file_name,ifile);
		fnames[f] = file_name;
	}

#if 0
	fprintf(stdout,"agent %d\n",id);
	for(f=0; f < fcount; f++) {
		fprintf(stdout,"\t%s\n",fnames[f]);
	}
#endif


	for(i=0; i < a->iterations; i++) {
		f = drand48() * fcount;
		fd = open(fnames[f],O_RDWR | O_CREAT,0644);
		if(fd < 0) {
			fprintf(stderr,"agent %d failed to open %s\n",
				id,
				fnames[f]);
			goto out;
		}

		size = drand48() * a->max_size;
		if(size < 2) {
			size = 2;
		}
		offset = drand48() * a->max_size;

		err = lseek(fd,offset,SEEK_SET);
		if(err < 0) {
			fprintf(stderr,
			"agent %d couldn't seek to %d in %s\n",
				id,
				offset,
				fnames[f]);
			goto out;
		}


		memset(wbuf,0,a->max_size+1);
		memset(rbuf,0,a->max_size+1);
		for(j=0; j < size; j++) {
			wbuf[j] = 'a'+(drand48()*25);
		}

		wbuf[size-1] = '\n';

		bytes = write(fd,wbuf,size);
		if(bytes != size) {
			fprintf(stderr,
			"agent %d tried %d but wrote %d at %d in %s\n",
			id,
			size,
			bytes,
			offset,
			fnames[f]);
			goto out;
		}

		err = lseek(fd,offset,SEEK_SET);
		if(err < 0) {
			fprintf(stderr,
			"agent %d couldn't reseek to %d in %s\n",
				id,
				offset,
				fnames[f]);
			goto out;
		}

		bytes = read(fd,rbuf,size);
		if(bytes < 0) {
			fprintf(stderr,
			"agent %d read failed for %d at %d in %s\n",
			id,
			size,
			offset,
			fnames[f]);
			goto out;
		}
		if(bytes == 0) {
			fprintf(stderr,
			"agent %d read EOF for %d at %d in %s\n",
			id,
			size,
			offset,
			fnames[f]);
			goto out;
		}
		if(bytes != size) {
			fprintf(stderr,
			"agent %d tried %d read %d at %d in %s\n",
			id,
			size,
			bytes,
			offset,
			fnames[f]);
			goto out;
		}

		for(j=0; j < size; j++) {
			if(wbuf[j] != rbuf[j]) {
				fprintf(stderr,
			"agent %d failed to compare at %d of iteration %d\n",
				id,
				j,
				i);
				goto out;
			}
		} 

		err = close(fd);
		if(err < 0) {
			fprintf(stderr,"agent %d couldn't close %s\n",
				id,
				fnames[f]);
			goto out;
		}
		local_ops++;
	}


	for(f=0; f < fcount; f++) {
		free(fnames[f]);
	}
	free(fnames);
	free(rbuf);
	free(wbuf);

	pthread_mutex_lock(&OpsLock);
	Operations += local_ops;
	pthread_mutex_unlock(&OpsLock);
	return(NULL);
out:
	for(f=0; f < fcount; f++) {
		free(fnames[f]);
	}
	free(fnames);
	free(rbuf);
	free(wbuf);
	exit(1);

}

#define ARGS "d:f:i:t:p:s:c:"
char *Usage = "file-test -i iterations\n\
\t-c max file count per thread\n\
\t-f fanout\n\
\t-d depth\n\
\t-p path\n\
\t-s file size in MB\n\
\t-t threads\n";

int main(int argc, char *argv[])
{
	int c;
	struct timeval start_time;
	struct timeval end_time;
	AGENTARG *a;
	pthread_t *tids;
	int i;
	double elapsed;

	Iterations = 1;
	Agents = 1;
	FileSize = 1;
	FanOut = 1;
	Depth = 1;
	FileCount = 1;

	while((c = getopt(argc,argv,ARGS)) != EOF) {
		switch(c) {
			case 'c':
				FileCount = atoi(optarg);
				break;
			case 'd':
				Depth = atoi(optarg);
				break;
			case 'f':
				FanOut = atoi(optarg);
				break;
			case 'i':
				Iterations = atoi(optarg);
				break;
			case 'p':
				strncpy(Path,optarg,sizeof(Path));
				break;
			case 't':
				Agents = atoi(optarg);
				break;
			case 's':
				FileSize = atoi(optarg);
				break;
			default:
				fprintf(stderr,
			"unrecognized command %c\n",(char)c);
				fprintf(stderr,"%s",Usage);
				exit(1);
		}
	}

	if(Path[0] == 0) {
		fprintf(stderr,"must enter path to test directory\n");
		fprintf(stderr,"%s",Usage);
		exit(1);
	}

	a = (AGENTARG *)malloc(sizeof(AGENTARG));
	if(a == NULL) {
		exit(1);
	}
	memset(a,0,sizeof(AGENTARG));

	tids = (pthread_t *)malloc(Agents * sizeof(pthread_t));
	if(tids == NULL) {
		exit(1);
	}

	a->max_size = FileSize*ONEMB;
	a->iterations = Iterations;
	a->path = Path;
	a->max_files = FileCount;
	a->depth = Depth;
	a->fanout = FanOut;
	

	for(i=0; i < Agents; i++) {
		pthread_create(&tids[i],NULL,agent,(void *)a);
	}
	gettimeofday(&start_time,NULL);
	for(i=0; i < Agents; i++) {
		pthread_join(tids[i],NULL);
	}
	gettimeofday(&end_time,NULL);

	elapsed = (end_time.tv_sec + (double)(end_time.tv_usec)/1000000.0) -
	      (start_time.tv_sec + (double)(start_time.tv_usec)/1000000.0);

	printf("%f ops/sec\n",Operations/elapsed);

	free(a);
	free(tids);

	return(0);
}
