#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <fcntl.h>
#include <string.h>
#include <sys/time.h>
#include <pthread.h>
#include <errno.h>

int Verbose;
char Path[1024];
char FileName[1024];
int Iterations;
int Agents;
unsigned long int FileSize;
int BufSize;

#define GB1 (1024*1024*1024)
#define MB1 (1024*1024)

double Operations;
pthread_mutex_t OpsLock;

struct agent_arg
{
	int ndx;
	unsigned long int file_size;
	int buf_size;
	int iterations;
	char *path;
	char *file_name;
};

typedef struct agent_arg AGENTARG;

void *agent(void *arg)
{
	AGENTARG *a = (AGENTARG *)arg;
	int fd;
	int i;
	int j;
	off_t offset;
	char *buf;
	char file_name[512];
	char dir_name[512];
	int id;
	double local_ops = 0;
	int err;
	char *rbuf;
	char *wbuf;
	int bytes;

	memset(file_name,0,sizeof(file_name));
	memset(dir_name,0,sizeof(dir_name));

	rbuf = malloc(a->buf_size);
	if(rbuf == NULL) {
		return(NULL);
	}
	wbuf = malloc(a->buf_size);
	if(wbuf == NULL) {
		free(rbuf);
		return(NULL);
	}

	id = a->ndx;

	for(i=0; i < a->iterations; i++) {
		fd = open(a->file_name,O_RDWR);
		if(fd < 0) {
			fprintf(stderr,"agent %d failed to open %s\n",
				id,
				file_name);
			free(rbuf);
			free(wbuf);
			exit(1);
			return(NULL);
		}

		offset = a->file_size - (a->ndx * a->buf_size);

		err = lseek(fd,offset,SEEK_SET);
		if(err < 0) {
			perror("lseek");
			fprintf(stderr,
			"agent %d couldn't seek to %ld in %s\n",
				id,
				offset,
				file_name);
			free(rbuf);
			free(wbuf);
			return(NULL);
		}


		memset(wbuf,0,a->buf_size+1);
		memset(rbuf,0,a->buf_size+1);
		for(j=0; j < a->buf_size; j++) {
			wbuf[j] = 'a'+(drand48()*25);
		}

		wbuf[a->buf_size-1] = '\n';

		bytes = write(fd,wbuf,a->buf_size);
		if(bytes != a->buf_size) {
			fprintf(stderr,
			"agent %d tried %d but wrote %d at %d in %s\n",
			id,
			a->buf_size,
			bytes,
			offset,
			file_name);
			free(rbuf);
			free(wbuf);
			return(NULL);
		}

		err = lseek(fd,offset,SEEK_SET);
		if(err < 0) {
			fprintf(stderr,
			"agent %d couldn't reseek to %d in %s\n",
				id,
				offset,
				file_name);
			free(rbuf);
			free(wbuf);
			return(NULL);
		}

		bytes = read(fd,rbuf,a->buf_size);
		if(bytes < 0) {
			fprintf(stderr,
			"agent %d read failed for %d at %d in %s\n",
			id,
			a->buf_size,
			offset,
			file_name);
			free(rbuf);
			free(wbuf);
			return(NULL);
		}
		if(bytes == 0) {
			fprintf(stderr,
			"agent %d read EOF for %d at %d in %s\n",
			id,
			a->buf_size,
			offset,
			file_name);
			free(rbuf);
			free(wbuf);
			return(NULL);
		}
		if(bytes != a->buf_size) {
			fprintf(stderr,
			"agent %d tried %d read %d at %d in %s\n",
			id,
			a->buf_size,
			bytes,
			offset,
			file_name);
			free(rbuf);
			free(wbuf);
			return(NULL);
		}

		for(j=0; j < a->buf_size; j++) {
			if(wbuf[j] != rbuf[j]) {
				fprintf(stderr,
			"agent %d failed to compare at %d of iteration %d\n",
				id,
				j,
				i);
				free(rbuf);
				free(wbuf);
				return(NULL);
			}
		} 

		err = close(fd);
		if(err < 0) {
			fprintf(stderr,"agent %d couldn't close %s\n",
				id,
				file_name);
			free(rbuf);
			free(wbuf);
			return(NULL);
		}
		local_ops++;
	}

	free(rbuf);
	free(wbuf);

	pthread_mutex_lock(&OpsLock);
	Operations += local_ops;
	pthread_mutex_unlock(&OpsLock);
	return(NULL);
}

#define ARGS "b:i:t:p:s:"
char *Usage = "file-test -i iterations\n\
\t-b bufsize\n\
\t-p path\n\
\t-s size (in GB)\n\
\t-t threads\n";

int main(int argc, char *argv[])
{
	int c;
	struct timeval start_time;
	struct timeval end_time;
	AGENTARG *a;
	pthread_t *tids;
	int i;
	double elapsed;
	char *wbuf;
	int fd;
	int err;
	int buildbufsize;

	Iterations = 1;
	Agents = 1;
	FileSize = GB1;
	BufSize = 4096;

	while((c = getopt(argc,argv,ARGS)) != EOF) {
		switch(c) {
			case 'b':
				BufSize = atoi(optarg);
				break;
			case 'i':
				Iterations = atoi(optarg);
				break;
			case 'p':
				strncpy(Path,optarg,sizeof(Path));
				break;
			case 't':
				Agents = atoi(optarg);
				break;
			case 's':
				FileSize = GB1 * atoll(optarg);
				break;
			default:
				fprintf(stderr,
			"unrecognized command %c\n",(char)c);
				fprintf(stderr,"%s",Usage);
				exit(1);
		}
	}

	if(Path[0] == 0) {
		fprintf(stderr,"must enter path to test directory\n");
		fprintf(stderr,"%s",Usage);
		exit(1);
	}

	sprintf(FileName,"%s/file%4.4d",
                Path,
                0);

	fd = open(FileName,O_RDWR | O_CREAT,0644);
	if(fd < 0) {
		fprintf(stderr,"couldn't open file %s\n",
		FileName);
		exit(1);
	}

	printf("FileSize: %d GB\n",FileSize / GB1);
	printf("BufSize: %d\n",BufSize);
	printf("Threads: %d\n",Agents);

	wbuf = (char *)malloc(BufSize);
	if(wbuf == NULL) {
		exit(1);
	}
	

#if 0
	for(i=0; i < BufSize; i++) {
		wbuf[i] = 'a';
	}
#endif

	buildbufsize = MB1*100;
	for(i=0; i < (FileSize / buildbufsize); i++) {
		err = write(fd,wbuf,buildbufsize);
		if(err <= 0) {
			fprintf(stderr,
			"couldn't write %d bytes into initial buf\n");
			exit(1);
		}
	}

	err = close(fd);
	if(err < 0) {
		fprintf(stderr,"error on initial close\n");
		exit(1);
	}

	a = (AGENTARG *)malloc(sizeof(AGENTARG));
	if(a == NULL) {
		exit(1);
	}
	memset(a,0,sizeof(AGENTARG));

	tids = (pthread_t *)malloc(Agents * sizeof(pthread_t));
	if(tids == NULL) {
		exit(1);
	}

	a->file_size = FileSize;
	a->buf_size = BufSize;
	a->file_name = FileName;
	a->iterations = Iterations;
	a->path = Path;

	gettimeofday(&start_time,NULL);
	for(i=0; i < Agents; i++) {
		a->ndx = i+1;
		pthread_create(&tids[i],NULL,agent,(void *)a);
	}
	for(i=0; i < Agents; i++) {
		pthread_join(tids[i],NULL);
	}
	gettimeofday(&end_time,NULL);

	elapsed = (end_time.tv_sec + (double)(end_time.tv_usec)/1000000.0) -
	      (start_time.tv_sec + (double)(start_time.tv_usec)/1000000.0);

	printf("%f ops/sec\n",Operations/elapsed);

	free(a);
	free(tids);

	return(0);
}
