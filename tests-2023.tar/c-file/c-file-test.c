#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <fcntl.h>
#include <string.h>
#include <sys/time.h>
#include <pthread.h>

int Verbose;
char Path[1024];
int Iterations;
int Agents;
int FileSize;

double Operations;
pthread_mutex_t OpsLock;

struct agent_arg
{
	int max_size;
	int max_offset;
	int iterations;
	char *path;
};

typedef struct agent_arg AGENTARG;

void *agent(void *arg)
{
	AGENTARG *a = (AGENTARG *)arg;
	int fd;
	int i;
	int j;
	int offset;
	char *buf;
	int size;
	char file_name[512];
	char dir_name[512];
	int id;
	double local_ops = 0;
	int err;
	char *rbuf;
	char *wbuf;
	int bytes;

	memset(file_name,0,sizeof(file_name));
	memset(dir_name,0,sizeof(dir_name));

	rbuf = malloc(a->max_size+1);
	if(rbuf == NULL) {
		return(NULL);
	}
	wbuf = malloc(a->max_size+1);
	if(wbuf == NULL) {
		free(rbuf);
		return(NULL);
	}

	id = (int)(drand48() * 10000.0);

	sprintf(file_name,"%s/file%4.4d",
		a->path,
		id);

	for(i=0; i < a->iterations; i++) {
		fd = open(file_name,O_RDWR | O_CREAT,0644);
		if(fd < 0) {
			fprintf(stderr,"agent %d failed to open %s\n",
				id,
				file_name);
			free(rbuf);
			free(wbuf);
			exit(1);
			return(NULL);
		}

		size = drand48() * a->max_size;
		if(size < 2) {
			size = 2;
		}
		offset = drand48() * a->max_size;

		err = lseek(fd,offset,SEEK_SET);
		if(err < 0) {
			fprintf(stderr,
			"agent %d couldn't seek to %d in %s\n",
				id,
				offset,
				file_name);
			free(rbuf);
			free(wbuf);
			return(NULL);
		}


		memset(wbuf,0,a->max_size+1);
		memset(rbuf,0,a->max_size+1);
		for(j=0; j < size; j++) {
			wbuf[j] = 'a'+(drand48()*25);
		}

		wbuf[size-1] = '\n';

		bytes = write(fd,wbuf,size);
		if(bytes != size) {
			fprintf(stderr,
			"agent %d tried %d but wrote %d at %d in %s\n",
			id,
			size,
			bytes,
			offset,
			file_name);
			free(rbuf);
			free(wbuf);
			return(NULL);
		}

		err = lseek(fd,offset,SEEK_SET);
		if(err < 0) {
			fprintf(stderr,
			"agent %d couldn't reseek to %d in %s\n",
				id,
				offset,
				file_name);
			free(rbuf);
			free(wbuf);
			return(NULL);
		}

		bytes = read(fd,rbuf,size);
		if(bytes < 0) {
			fprintf(stderr,
			"agent %d read failed for %d at %d in %s\n",
			id,
			size,
			offset,
			file_name);
			free(rbuf);
			free(wbuf);
			return(NULL);
		}
		if(bytes == 0) {
			fprintf(stderr,
			"agent %d read EOF for %d at %d in %s\n",
			id,
			size,
			offset,
			file_name);
			free(rbuf);
			free(wbuf);
			return(NULL);
		}
		if(bytes != size) {
			fprintf(stderr,
			"agent %d tried %d read %d at %d in %s\n",
			id,
			size,
			bytes,
			offset,
			file_name);
			free(rbuf);
			free(wbuf);
			return(NULL);
		}

		for(j=0; j < size; j++) {
			if(wbuf[j] != rbuf[j]) {
				fprintf(stderr,
			"agent %d failed to compare at %d of iteration %d\n",
				id,
				j,
				i);
				free(rbuf);
				free(wbuf);
				return(NULL);
			}
		} 

		err = close(fd);
		if(err < 0) {
			fprintf(stderr,"agent %d couldn't close %s\n",
				id,
				file_name);
			free(rbuf);
			free(wbuf);
			return(NULL);
		}
		local_ops++;
	}

	free(rbuf);
	free(wbuf);

	pthread_mutex_lock(&OpsLock);
	Operations += local_ops;
	pthread_mutex_unlock(&OpsLock);
	return(NULL);
}

#define ARGS "i:t:p:s:"
char *Usage = "file-test -i iterations\n\
\t-p path\n\
\t-s size\n\
\t-t threads\n";

int main(int argc, char *argv[])
{
	int c;
	struct timeval start_time;
	struct timeval end_time;
	AGENTARG *a;
	pthread_t *tids;
	int i;
	double elapsed;

	Iterations = 1;
	Agents = 1;
	FileSize = 1024;

	while((c = getopt(argc,argv,ARGS)) != EOF) {
		switch(c) {
			case 'i':
				Iterations = atoi(optarg);
				break;
			case 'p':
				strncpy(Path,optarg,sizeof(Path));
				break;
			case 't':
				Agents = atoi(optarg);
				break;
			case 's':
				FileSize = atoi(optarg);
				break;
			default:
				fprintf(stderr,
			"unrecognized command %c\n",(char)c);
				fprintf(stderr,"%s",Usage);
				exit(1);
		}
	}

	if(Path[0] == 0) {
		fprintf(stderr,"must enter path to test directory\n");
		fprintf(stderr,"%s",Usage);
		exit(1);
	}

	a = (AGENTARG *)malloc(sizeof(AGENTARG));
	if(a == NULL) {
		exit(1);
	}
	memset(a,0,sizeof(AGENTARG));

	tids = (pthread_t *)malloc(Agents * sizeof(pthread_t));
	if(tids == NULL) {
		exit(1);
	}

	a->max_size = FileSize;
	a->iterations = Iterations;
	a->path = Path;

	for(i=0; i < Agents; i++) {
		pthread_create(&tids[i],NULL,agent,(void *)a);
	}
	gettimeofday(&start_time,NULL);
	for(i=0; i < Agents; i++) {
		pthread_join(tids[i],NULL);
	}
	gettimeofday(&end_time,NULL);

	elapsed = (end_time.tv_sec + (double)(end_time.tv_usec)/1000000.0) -
	      (start_time.tv_sec + (double)(start_time.tv_usec)/1000000.0);

	printf("%f ops/sec\n",Operations/elapsed);

	free(a);
	free(tids);

	return(0);
}
