#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <math.h>
#include <fcntl.h>
#include <errno.h>

#define ARGS "d:I:i:o:"
char *Usage="c-file-test-5 -d directory\n\
\t-I iterations\n\
\t-i max_interval\n\
\t-o max_offset\n";


int main(int argc, char **argv)
{
	int c;
	int i;
	int j;
	int k;
	char fname[255];
	char dname[255];
	char buf[255];
	int pid;
	unsigned int interval;
	unsigned int offset;
	unsigned int size;
	unsigned int iterations;
	int count; /* number of outstanding files can't exceed fs size */
	double r;
	int fd;
	FILE *sd;
	int l_interval;
	int l_offset;
	int err;
	char *cerr;
	int status;
	char dummy;

	memset(dname,0,sizeof(dname));
	interval = 0;
	offset = 0;
	size = 0;
	iterations = 0;
	while((c = getopt(argc,argv,ARGS)) != EOF) {
		switch(c) {
			case 'd':
				strcpy(dname,optarg);
				break;
			case 'i':
				interval = atoi(optarg);
				break;
			case 'I':
				iterations = atoi(optarg);
				break;
			case 'o':
				offset = atoi(optarg);
				break;
			default:
				fprintf(stdout,"unrecognized arg %c\n",
					(char)c);
				fprintf(stdout,"%s",Usage);
					exit(1);
		}
	}

	if(iterations == 0) {
		fprintf(stdout,
			"must enter iterations\n");
		fprintf(stdout,"%s",Usage);
		exit(1);
	}
	if(interval == 0) {
		fprintf(stdout,
			"must enter interval\n");
		fprintf(stdout,"%s",Usage);
		exit(1);
	}
	if(offset == 0) {
		fprintf(stdout,
			"must enter offset\n");
		fprintf(stdout,"%s",Usage);
		exit(1);
	}
	if(dname[0] == 0) {
		fprintf(stdout,
			"must enter directory name\n");
		fprintf(stdout,"%s",Usage);
		exit(1);
	}

	err = mkdir(dname,0700);
	if(err < 0) {
		fprintf(stdout,"FAIL couldn't create dirtectory %s\n",
			dname);
		exit(1);
	}

	count = 0;
	for(i=0; i < iterations; i++) {
		r = drand48() * 100000;
		memset(fname,0,sizeof(fname));
		sprintf(fname,"./%s/file%10.10d",dname,(int)r);
		fd = open(fname,O_WRONLY|O_CREAT,0600);
		if(fd < 0) {
			fprintf(stdout,
				"FAIL couldn't open file %s for writing\n",
				fname);
			perror("file for write");
			exit(1);
		}
		l_interval = (int)(drand48() * interval);
		l_offset = (int)(drand48() * offset);

		err = lseek(fd,l_offset,SEEK_SET);
		if(err < 0) {
			fprintf(stdout,
				"FAIL couldn't seek to %d in file %s\n",
					l_offset,fname);
			perror("lseek write");
			exit(1);
		}
		for(j=0; j < l_interval; j++) {
			memset(buf,0,sizeof(buf));
			sprintf(buf,"%7.7d\n",j);
			err = write(fd,buf,strlen(buf));
			if(err < 0) {
				fprintf(stdout,
				"FAIL write failed for %s in %s\n",
					buf,
					fname);
				perror("buf write");
				exit(1);
			}
		}
		err = close(fd);
		if(err < 0) {
			fprintf(stdout,
			"FAIL close failed for %s\n",fname);
			perror("write close");
			exit(1);
		}


		count++;
		pid = fork();
		if(pid < 0) {
			fprintf(stdout,
				"FAIL fork failed at %d count %d\n",
					i,
					count);
			perror("fork");
			exit(1);
		}

		
		if(pid == 0) { /* child */
			sd = fopen(fname,"r");
			if(sd == NULL) {
				fprintf(stdout,
				"FAIL couldn't open %s for read\n",
				fname);
				perror("read open");
				exit(1);
			}
			err = fseek(sd,l_offset,SEEK_SET);
			if(err < 0) {
				fprintf(stdout,
				"FAIL couldn't seek to %d in %s on read\n",
					l_offset,fname);
				perror("lseek read");
				exit(1);
			}
			for(j=0; j < l_interval; j++) {
				memset(buf,0,sizeof(buf));
				cerr = fgets(buf,sizeof(buf),sd);
				if(cerr == NULL) {
					fprintf(stdout,
					"FAIL couldn't fgets from %s\n",
					fname);
					perror("fgets");
					exit(1);
				}
/*
printf("READ %d %s",j,buf);
fflush(stdout);
*/
				k = atoi(buf);
				if(j != k) {
					fprintf(stdout,
					"FAIL %d != %d (%s) in %s\n",
					j,k,buf,fname);
					fflush(stdout);
					exit(1);
				}
				/* read the new line
				err = read(fileno(sd),&dummy,1);
                                if(err < 0) {
                                        printf("FAIL couldn't nl fgets from %s\n",
                                        fname);
                                        fprintf(stdout,
                                        "FAIL couldn't nl fgets from %s\n",
                                        fname);
//                                       perror("fgets");
                                        exit(1);
                                }
				*/

			}
			err = fclose(sd);
			if(err < 0) {
				fprintf(stdout,
				"FAIL failed to fclose %s\n",
				fname);
				perror("fclose");
				exit(1);
			}
			err = unlink(fname);
			if(err < 0) {
				fprintf(stdout,
				"FAIL failed to unlink %s\n",
				fname);
				perror("unlink");
				exit(1);
			}
			exit(0); /* child exits successfully */
		} else { /* parent */
			if(count < 20) {
				pid = wait4(-1,&status,WNOHANG,NULL);
				if((pid > 0) && (WEXITSTATUS(status) != 0)) {
					fprintf(stdout,"child exited %d\n",
					WEXITSTATUS(status));
					fflush(stdout);
					exit(1);
				}
				while(pid > 0) {
					count--;
					pid = wait4(-1,&status,WNOHANG,NULL);
				}
			} else {
				pid = wait(&status);
				if((pid > 0) && 
				   (WEXITSTATUS(status) != 0)) {
					fprintf(stdout,"child wait exited %d\n",
					WEXITSTATUS(status));
					exit(1);
				}
				count--;
			}
		}
	}

	printf("c-file-test-5 SUCCESS\n");
	fflush(stdout);
	exit(0);
}
				
				
		

			


