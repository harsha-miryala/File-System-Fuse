#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <fcntl.h>
#include <string.h>
#include <errno.h>
#include <sys/time.h>
#include <sys/stat.h>
#include <pthread.h>
#include <errno.h>

#include "ostypes.h"

int Verbose;
int Iterations;
int Agents;
int Size;

#define PREFIX "./test-5-files"

struct agent_arg
{
	int mode;
	int wpd;
	int rpd;
	int fd;
	int size;
	int iterations;
};

typedef struct agent_arg AGENTARG;

int agent(void *arg)
{
	AGENTARG *a = (AGENTARG *)arg;
	int fd;
	int pd;
	char *pbuf;
	char *buf;
	int bytes;
	int bwritten;
	int bread;
	int i;
	char c;
	int rbytes;
	int wbytes;

	buf = (char *)malloc(a->size+1);
	if(buf == NULL) {
		return(-1);
	}
	pbuf = (char *)malloc(a->size+1);
	if(pbuf == NULL) {
		free(buf);
		return(-1);
	}

	if(a->size < 11) {
		fprintf(stderr,"size must be bigger than 11\n");
		fflush(stderr);
		return(-1);
	}

	/*
	 * mode 0 is writer, mode 1 is reader
	 */
	
	if(a->mode == 0) {
		for(i=0; i < a->iterations; i++) {
			memset(pbuf,0,a->size+1);
			memset(buf,0,a->size+1);
			sprintf(pbuf,"%10.10d",i);
			strcpy(buf,pbuf);
			/*
			 * write the file first
			 */
			bytes = 0;
			while(bytes < a->size) {
				bwritten = write(a->fd,buf,a->size);
				if(bwritten <= 0) {
					return(-1 * i);
				}
				bytes += bwritten;
			}
			/*
			 * now write the pipe
			 */
			bytes = 0;
			while(bytes < a->size) {
				bwritten = write(a->wpd,pbuf,a->size);
				if(bwritten <= 0) {
					return(-1 * i);
				}
				bytes += bwritten;
			}
			rbytes = read(a->rpd,&c,1);
			if(rbytes <= 0)  {
				perror("writer response pipe");
				return(-1 * i);
			}
		}
		/*
		 * writer done
		 */
		return(i);
	} else { /* reader code */
		for(i=0; i < a->iterations; i++) {
			memset(pbuf,0,a->size+1);
			memset(buf,0,a->size+1);
			/*
			 * read the pipe first
			 */
			bytes = 0;
			while(bytes < a->size) {
				bread = read(a->rpd,pbuf+bytes,a->size-bytes);
				if(bread <= 0) {
					perror("reader pipe");
					return(-1 * i);
				}
				bytes += bread;
			}
			bytes = 0;
			while(bytes < a->size) {
				bread = read(a->fd,buf,a->size);
				if(bread <= 0) {
					perror("reader file");
					return(-1 * i);
				}
				bytes += bread;
			}

			wbytes = write(a->wpd,&c,1);
			if(wbytes != 1) {
				perror("reader response pipe");
				return(-1 * i);
			}

			if(memcmp(buf,pbuf,a->size) != 0) {
				fprintf(stderr,"reader failed to compare file %s to pipe %s\n",buf,pbuf);
				fflush(stderr);
				return(-1 * i);
			}
		}
		/* reader all done */
		return(i);
	}
		
}

#define ARGS "a:i:s:"
char *Usage = "file-test-4 -a agents (process pairs)\n\
\t-i iterations\n\
\t-s file size in bytes";

int main(int argc, char *argv[])
{
	int c;
	struct timeval start_time;
	struct timeval end_time;
	AGENTARG *a;
	int i;
	double elapsed;
	char *filename;
	int err;
	int wfd;
	int rfd;
	int pd[2];
	int pd1[2];
	int child_status;
	pid_t rpid;
	pid_t wpid;
	pid_t pid;

	Iterations = 1;
	Agents = 1;
	Size = 20;

	while((c = getopt(argc,argv,ARGS)) != EOF) {
		switch(c) {
			case 'a':
				Agents = atoi(optarg);
				break;
			case 'i':
				Iterations = atoi(optarg);
				break;
			case 's':
				Size = atoi(optarg);
				break;
			default:
				fprintf(stderr,
			"unrecognized command %c\n",(char)c);
				fprintf(stderr,"%s",Usage);
				exit(1);
		}
	}


	if(Iterations < 1) {
		fprintf(stderr,"must specify at least 1 iteration\n");
		exit(1);
	}

	if(Size < 11) {
		fprintf(stderr,"size must be at least 11\n");
		exit(1);
	}

	if(Agents < 1) {
		fprintf(stderr,"must have at least 1 pair of agents\n");
		exit(1);
	}

	err = mkdir(PREFIX,0755);
	if((err < 0) && (errno != EEXIST)) {
		perror(PREFIX);
		exit(1);
	}

	for(i=0; i < Agents; i++) {
		/*
		 * make sender/receiver pairs
		 */
		filename = (char *)malloc(255);
		if(filename == NULL) {
			exit(1);
		}
		memset(filename,0,255);
		sprintf(filename,"%s/%s%10.10d",PREFIX,"file",i);

		wfd = open(filename,O_WRONLY| O_CREAT,0644);
		if(wfd < 0) {
			perror(filename);
			exit(1);
		}

		rfd = open(filename,O_RDONLY | O_CREAT,0644);
		if(rfd < 0) {
			perror(filename);
			exit(1);
		}

		err = pipe(pd);
		if(err < 0) {
			perror("PIPE");
			exit(1);
		}
		err = pipe(pd1);
		if(err < 0) {
			perror("PIPE 1");
			exit(1);
		}
		a = (AGENTARG *)malloc(sizeof(AGENTARG));
		if(a == NULL) {
			exit(1);
		}
		memset(a,0,sizeof(AGENTARG));

		a->size = Size;
		a->iterations = Iterations;

		rpid = fork();
		if(rpid < 0) {
			perror("reader fork");
			exit(1);
		}

		if(rpid == 0) { /* I am the reader child */
			a->mode = 1;
			a->fd = rfd;
			a->rpd = pd[0];
			a->wpd = pd1[1];
			err = agent(a);
			if(err <= 0) {
				fprintf(stderr,"Reader Agent %d FAILED at iteration %d\n",i,-1*err);
				close(a->fd);
				close(a->rpd);
				close(a->wpd);
				exit(1);
			}
			close(a->fd);
			close(a->wpd);
			close(a->rpd);
			exit(0);
		}

		/*
		 * writer must fork reader or it will exit before reader has a chance
		 */
		wpid = fork();
		if(wpid < 0) {
			perror("writer fork failed\n");
			/*
			 * close the descriptors -- will cause reader to exit
			 */
			close(pd[0]);
			close(pd[1]);
			close(pd1[0]);
			close(pd1[1]);
			close(wfd);
			close(rfd);
			exit(1);
		}

		if(wpid == 0) { /* I am the writer */
			a->mode = 0;
			a->fd = wfd;
			a->wpd = pd[1];
			a->rpd = pd1[0];
			err = agent(a);
			if(err <= 0) {
				fprintf(stderr,"Writer Agent %d FAILED at iteration %d\n",i,-1*err);
				close(a->fd);
				close(a->rpd);
				close(a->wpd);
				exit(1);
			}
			close(a->fd);
			close(a->wpd);
			close(a->rpd);
			exit(0);
		}

		/*
		 * parent doesn't need these any more
		 */
		close(rfd);
		close(wfd);
		close(pd[0]);
		close(pd[1]);
		close(pd1[0]);
		close(pd1[1]);

	}

	/*
	 * wait for all children to finish
	 */
	err = 0;
	for(i=0; i < 2*Agents; i++) {
		child_status = 0;
		pid = wait(&child_status);
		if(pid <= 0) {
			perror("wait");
			exit(1);
		}
		if(WIFEXITED(child_status) && 
			(WEXITSTATUS(child_status) == 0)) {
			continue;
		}
		fprintf(stderr,"main FAILED because of non zero child exit\n");
		err = 1;
	}


	free(a);

	if(err == 0) {
		printf("main SUCCESS for %d agent pairs, %d iterations, and %d bytes\n",
				Agents,Iterations,Size);
		fflush(stdout);
	}

	exit(0);
}
