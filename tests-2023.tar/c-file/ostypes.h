#ifndef OSTYPES_H
#define OSTYPES_H

typedef unsigned char uchar;
typedef unsigned int uint;
typedef unsigned long long ull;

#endif

