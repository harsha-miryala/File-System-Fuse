#!/bin/bash

if ( test -z "$1" ) ; then
	echo "make-tar.sh tarfilename.tar"
	exit 1
fi

tar -cf $1 make* c-file/*.[ch] c-file/makefile bonnie*

